import React, { useEffect, useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Skills from './components/Skills';
import Projects from './components/Projects';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Cursor from './components/Cursor';

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-black">
        <div className="text-center">
          <h1 className="font-mono text-3xl font-bold text-primary-500 mb-2">
            <span className="inline-block">Initializing</span>
            <span className="inline-block animate-pulse">_</span>
          </h1>
          <p className="text-gray-400 font-mono">Um3r.xeh</p>
        </div>
      </div>
    );
  }

  return (
    <ThemeProvider>
      <div className="bg-dark-900 text-gray-100 min-h-screen">
        <Cursor />
        <Navbar />
        <main>
          <Hero />
          <About />
          <Skills />
          <Projects />
          <Contact />
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}

export default App;