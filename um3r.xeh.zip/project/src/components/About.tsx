import React from 'react';
import { Shield, Code, Wifi, Key } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-dark-800">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-primary-500">&lt;</span> About Me <span className="text-primary-500">/&gt;</span>
          </h2>
          <div className="w-20 h-1 bg-primary-500 mx-auto mb-8"></div>
          <p className="text-gray-300 text-lg leading-relaxed">
            With over 8 years of experience in cybersecurity, I specialize in identifying 
            and exploiting vulnerabilities in web applications, networks, and infrastructure. 
            My mission is to help organizations strengthen their security posture before 
            malicious actors can exploit weaknesses.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-dark-700 p-6 rounded-lg border border-gray-700 hover:border-primary-500 transition-all hover:shadow-[0_0_15px_rgba(0,255,140,0.15)] group">
            <div className="bg-dark-600 w-16 h-16 rounded-lg flex items-center justify-center mb-6 text-primary-500 group-hover:scale-110 transition-transform">
              <Wifi size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Network Security</h3>
            <p className="text-gray-400">
              Identifying vulnerabilities in network infrastructure through comprehensive penetration testing and security assessments.
            </p>
          </div>
          
          <div className="bg-dark-700 p-6 rounded-lg border border-gray-700 hover:border-primary-500 transition-all hover:shadow-[0_0_15px_rgba(0,255,140,0.15)] group">
            <div className="bg-dark-600 w-16 h-16 rounded-lg flex items-center justify-center mb-6 text-primary-500 group-hover:scale-110 transition-transform">
              <Code size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Web Application Security</h3>
            <p className="text-gray-400">
              Detecting and exploiting vulnerabilities in web applications, including OWASP Top 10 risks and custom application logic flaws.
            </p>
          </div>
          
          <div className="bg-dark-700 p-6 rounded-lg border border-gray-700 hover:border-primary-500 transition-all hover:shadow-[0_0_15px_rgba(0,255,140,0.15)] group">
            <div className="bg-dark-600 w-16 h-16 rounded-lg flex items-center justify-center mb-6 text-primary-500 group-hover:scale-110 transition-transform">
              <Shield size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Secure Development</h3>
            <p className="text-gray-400">
              Implementing secure coding practices and security-first design principles to prevent vulnerabilities during development.
            </p>
          </div>
          
          <div className="bg-dark-700 p-6 rounded-lg border border-gray-700 hover:border-primary-500 transition-all hover:shadow-[0_0_15px_rgba(0,255,140,0.15)] group">
            <div className="bg-dark-600 w-16 h-16 rounded-lg flex items-center justify-center mb-6 text-primary-500 group-hover:scale-110 transition-transform">
              <Key size={32} />
            </div>
            <h3 className="text-xl font-bold mb-3">Security Research</h3>
            <p className="text-gray-400">
              Conducting original security research to discover new attack vectors and developing custom tools for advanced penetration testing.
            </p>
          </div>
        </div>
        
        <div className="mt-16 p-8 bg-dark-700 rounded-lg border border-gray-700">
          <h3 className="text-2xl font-bold mb-4 text-primary-500">My Approach</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <p className="text-gray-300 mb-4">
                I believe in a holistic approach to security that combines technical expertise with strategic thinking. 
                By understanding both offensive and defensive aspects of cybersecurity, I help clients build robust 
                security programs that stand up to real-world attacks.
              </p>
              <p className="text-gray-300">
                Each engagement begins with a thorough understanding of the client's business, technology stack, and 
                threat landscape. This context-aware approach ensures that security recommendations are relevant, 
                practical, and aligned with business objectives.
              </p>
            </div>
            <div>
              <div className="font-mono mb-6">
                <div className="text-gray-400">// Ethical Hacking Workflow</div>
                <div className="text-primary-500">function <span className="text-white">securityAssessment</span>() &#123;</div>
                <div className="ml-4">
                  <div className="text-gray-300">1. Reconnaissance</div>
                  <div className="text-gray-300">2. Vulnerability Scanning</div>
                  <div className="text-gray-300">3. Exploitation</div>
                  <div className="text-gray-300">4. Post-Exploitation</div>
                  <div className="text-gray-300">5. Analysis</div>
                  <div className="text-gray-300">6. Reporting</div>
                  <div className="text-gray-300">7. Remediation Support</div>
                </div>
                <div className="text-primary-500">&#125;</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;