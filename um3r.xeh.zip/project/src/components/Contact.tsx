import React, { useState } from 'react';
import { Send, Mail, Github, Linkedin, Twitter } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const [encryptedMessage, setEncryptedMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Simulate encryption for the message field
    if (name === 'message') {
      const encrypted = Array.from(value)
        .map((char, i) => {
          // Simple character shifting for visual effect
          const code = char.charCodeAt(0);
          return String.fromCharCode((code + 7) % 128);
        })
        .join('');
      
      setEncryptedMessage(encrypted);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      // Reset form after submission
      setTimeout(() => {
        setFormData({
          name: '',
          email: '',
          subject: '',
          message: ''
        });
        setEncryptedMessage('');
        setIsSubmitted(false);
      }, 5000);
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-dark-900">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-primary-500">&lt;</span> Contact <span className="text-primary-500">/&gt;</span>
          </h2>
          <div className="w-20 h-1 bg-primary-500 mx-auto mb-8"></div>
          <p className="text-gray-300 text-lg">
            Have a security challenge or interested in collaboration? 
            Reach out through secure channels for a confidential discussion.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="bg-dark-800 p-8 rounded-lg border border-gray-700">
            <h3 className="text-2xl font-bold mb-6">Send a Secure Message</h3>
            
            {isSubmitted ? (
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-primary-900 rounded-full flex items-center justify-center mx-auto mb-4 text-primary-500">
                  <Send size={24} />
                </div>
                <h4 className="text-xl font-bold text-primary-500 mb-2">Message Sent Successfully</h4>
                <p className="text-gray-300">Your encrypted message has been transmitted securely.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="name" className="block text-gray-300 mb-2 font-medium">Name</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-dark-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-gray-200"
                    placeholder="Enter your name"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="email" className="block text-gray-300 mb-2 font-medium">Email</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-dark-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-gray-200"
                    placeholder="Enter your email"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="subject" className="block text-gray-300 mb-2 font-medium">Subject</label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-dark-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-gray-200"
                    placeholder="Enter subject"
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="message" className="block text-gray-300 mb-2 font-medium">Message</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 bg-dark-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-gray-200 resize-none"
                    placeholder="Enter your message"
                  ></textarea>
                </div>
                
                {formData.message && (
                  <div className="mb-6 p-3 bg-dark-700 rounded-md border border-gray-600">
                    <div className="font-mono text-xs text-gray-400 mb-1">// Encrypted Message Preview</div>
                    <div className="font-mono text-sm text-primary-500 break-all">
                      {encryptedMessage}
                    </div>
                  </div>
                )}
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full py-3 rounded-md font-medium flex items-center justify-center ${
                    isSubmitting
                      ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                      : 'bg-primary-500 text-dark-900 hover:bg-primary-600'
                  } transition-colors`}
                >
                  {isSubmitting ? (
                    <>
                      <span className="mr-2">Encrypting & Sending</span>
                      <div className="w-5 h-5 border-2 border-t-transparent border-dark-900 rounded-full animate-spin"></div>
                    </>
                  ) : (
                    <>
                      <Send size={18} className="mr-2" />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
          
          {/* Contact Info */}
          <div>
            <div className="bg-dark-800 p-8 rounded-lg border border-gray-700 mb-8">
              <h3 className="text-2xl font-bold mb-6">Connect</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-10 h-10 bg-dark-700 rounded-lg flex items-center justify-center text-primary-500 mr-4">
                    <Mail size={20} />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Email</h4>
                    <a href="mailto:contact@um3r.xeh" className="text-gray-300 hover:text-primary-500 transition-colors">
                      contact@um3r.xeh
                    </a>
                    <p className="text-gray-500 text-sm mt-1">For secure communications, please use PGP encryption</p>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-700">
                  <h4 className="text-lg font-semibold mb-4">Social Profiles</h4>
                  <div className="flex space-x-4">
                    <a 
                      href="#" 
                      className="w-12 h-12 bg-dark-700 rounded-lg flex items-center justify-center text-gray-400 hover:text-primary-500 hover:border-primary-500 border border-gray-700 transition-all"
                      aria-label="GitHub"
                    >
                      <Github size={22} />
                    </a>
                    <a 
                      href="#" 
                      className="w-12 h-12 bg-dark-700 rounded-lg flex items-center justify-center text-gray-400 hover:text-primary-500 hover:border-primary-500 border border-gray-700 transition-all"
                      aria-label="LinkedIn"
                    >
                      <Linkedin size={22} />
                    </a>
                    <a 
                      href="#" 
                      className="w-12 h-12 bg-dark-700 rounded-lg flex items-center justify-center text-gray-400 hover:text-primary-500 hover:border-primary-500 border border-gray-700 transition-all"
                      aria-label="Twitter"
                    >
                      <Twitter size={22} />
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-dark-800 p-8 rounded-lg border border-gray-700">
              <h3 className="text-2xl font-bold mb-6">Engagement Process</h3>
              
              <div className="space-y-6">
                <div className="flex">
                  <div className="mr-4 flex flex-col items-center">
                    <div className="w-8 h-8 bg-primary-500 text-dark-900 rounded-full flex items-center justify-center font-bold">1</div>
                    <div className="w-0.5 h-full bg-gray-700 mt-2"></div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Initial Contact</h4>
                    <p className="text-gray-400 text-sm">Secure communication established to discuss project requirements</p>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="mr-4 flex flex-col items-center">
                    <div className="w-8 h-8 bg-primary-500 text-dark-900 rounded-full flex items-center justify-center font-bold">2</div>
                    <div className="w-0.5 h-full bg-gray-700 mt-2"></div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Scope Definition</h4>
                    <p className="text-gray-400 text-sm">Clear definition of objectives, boundaries, and deliverables</p>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="mr-4 flex flex-col items-center">
                    <div className="w-8 h-8 bg-primary-500 text-dark-900 rounded-full flex items-center justify-center font-bold">3</div>
                    <div className="w-0.5 h-full bg-gray-700 mt-2"></div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Execution</h4>
                    <p className="text-gray-400 text-sm">Methodical approach with regular progress updates</p>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="mr-4 flex flex-col items-center">
                    <div className="w-8 h-8 bg-primary-500 text-dark-900 rounded-full flex items-center justify-center font-bold">4</div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Comprehensive Reporting</h4>
                    <p className="text-gray-400 text-sm">Detailed findings with actionable recommendations</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;