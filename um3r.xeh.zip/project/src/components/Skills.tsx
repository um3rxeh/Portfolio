import React, { useState } from 'react';
import { Skill } from '../types';
import { 
  Shield, Code, Server, Bug, Lock, Wifi, Database, 
  Terminal, Globe, Cpu, Network, FileCode, Search, AlertCircle 
} from 'lucide-react';

const skillsData: Skill[] = [
  // Offensive Skills
  { name: 'Penetration Testing', level: 95, category: 'offensive', icon: 'Bug' },
  { name: 'Web App Security', level: 90, category: 'offensive', icon: 'Globe' },
  { name: 'Social Engineering', level: 85, category: 'offensive', icon: 'Users' },
  { name: 'Exploit Development', level: 80, category: 'offensive', icon: 'Code' },
  { name: 'Wireless Security', level: 75, category: 'offensive', icon: 'Wifi' },
  
  // Defensive Skills
  { name: 'Incident Response', level: 85, category: 'defensive', icon: 'AlertCircle' },
  { name: 'Security Architecture', level: 90, category: 'defensive', icon: 'Shield' },
  { name: 'Threat Intelligence', level: 80, category: 'defensive', icon: 'Search' },
  { name: 'Digital Forensics', level: 75, category: 'defensive', icon: 'HardDrive' },
  { name: 'Security Monitoring', level: 85, category: 'defensive', icon: 'Activity' },
  
  // Development Skills
  { name: 'Python', level: 90, category: 'development', icon: 'FileCode' },
  { name: 'JavaScript', level: 85, category: 'development', icon: 'FileCode' },
  { name: 'Bash Scripting', level: 80, category: 'development', icon: 'Terminal' },
  { name: 'C/C++', level: 75, category: 'development', icon: 'FileCode' },
  { name: 'Go', level: 70, category: 'development', icon: 'FileCode' },
  
  // Infrastructure Skills
  { name: 'Linux Administration', level: 95, category: 'infrastructure', icon: 'Terminal' },
  { name: 'Cloud Security (AWS/Azure)', level: 85, category: 'infrastructure', icon: 'Cloud' },
  { name: 'Network Infrastructure', level: 90, category: 'infrastructure', icon: 'Network' },
  { name: 'Containerization', level: 80, category: 'infrastructure', icon: 'Box' },
  { name: 'Database Security', level: 75, category: 'infrastructure', icon: 'Database' },
];

const getIconComponent = (iconName: string | undefined) => {
  const icons: Record<string, React.ReactNode> = {
    Bug: <Bug size={20} />,
    Globe: <Globe size={20} />,
    Users: <Shield size={20} />,
    Code: <Code size={20} />,
    Wifi: <Wifi size={20} />,
    AlertCircle: <AlertCircle size={20} />,
    Shield: <Shield size={20} />,
    Search: <Search size={20} />,
    HardDrive: <Lock size={20} />,
    Activity: <Shield size={20} />,
    FileCode: <FileCode size={20} />,
    Terminal: <Terminal size={20} />,
    Cloud: <Server size={20} />,
    Network: <Network size={20} />,
    Box: <Server size={20} />,
    Database: <Database size={20} />,
  };
  
  return iconName ? icons[iconName] || <Code size={20} /> : <Code size={20} />;
};

const Skills: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  
  const filteredSkills = activeCategory === 'all' 
    ? skillsData 
    : skillsData.filter(skill => skill.category === activeCategory);
    
  const categories = [
    { id: 'all', name: 'All Skills' },
    { id: 'offensive', name: 'Offensive Security' },
    { id: 'defensive', name: 'Defensive Security' },
    { id: 'development', name: 'Development' },
    { id: 'infrastructure', name: 'Infrastructure' },
  ];

  return (
    <section id="skills" className="py-24 bg-dark-900">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-primary-500">&lt;</span> Technical Skills <span className="text-primary-500">/&gt;</span>
          </h2>
          <div className="w-20 h-1 bg-primary-500 mx-auto mb-8"></div>
          <p className="text-gray-300 text-lg">
            A comprehensive set of cybersecurity skills developed through years of hands-on experience,
            continuous learning, and real-world application.
          </p>
        </div>
        
        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map(category => (
            <button
              key={category.id}
              className={`px-5 py-2 rounded-full font-medium transition-colors ${
                activeCategory === category.id
                  ? 'bg-primary-500 text-dark-900'
                  : 'bg-dark-700 text-gray-300 hover:bg-dark-600'
              }`}
              onClick={() => setActiveCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSkills.map((skill, index) => (
            <div 
              key={index}
              className="bg-dark-800 p-5 rounded-lg border border-gray-700 hover:border-primary-500 transition-all group"
            >
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 rounded-lg bg-dark-600 flex items-center justify-center text-primary-500 mr-3 group-hover:scale-110 transition-transform">
                  {getIconComponent(skill.icon)}
                </div>
                <h3 className="font-bold text-lg">{skill.name}</h3>
              </div>
              
              <div className="mb-2 flex justify-between items-center">
                <div className="w-full bg-dark-600 rounded-full h-2 mr-2">
                  <div 
                    className="bg-primary-500 h-2 rounded-full relative group" 
                    style={{ width: `${skill.level}%` }}
                  >
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="bg-dark-700 text-primary-500 text-xs font-mono py-1 px-2 rounded whitespace-nowrap">
                        {skill.level}%
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Certifications */}
        <div className="mt-20 bg-dark-800 p-8 rounded-lg border border-gray-700">
          <h3 className="text-2xl font-bold mb-6 text-center">Certifications & Achievements</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-4 bg-dark-700 rounded-lg flex flex-col h-full">
              <div className="font-mono text-primary-500 text-sm mb-2">// VERIFIED</div>
              <h4 className="text-xl font-bold mb-2">OSCP</h4>
              <p className="text-gray-400 text-sm flex-grow">Offensive Security Certified Professional</p>
              <div className="text-xs text-gray-500 mt-3">Achieved: 2021</div>
            </div>
            
            <div className="p-4 bg-dark-700 rounded-lg flex flex-col h-full">
              <div className="font-mono text-primary-500 text-sm mb-2">// VERIFIED</div>
              <h4 className="text-xl font-bold mb-2">CEH</h4>
              <p className="text-gray-400 text-sm flex-grow">Certified Ethical Hacker</p>
              <div className="text-xs text-gray-500 mt-3">Achieved: 2020</div>
            </div>
            
            <div className="p-4 bg-dark-700 rounded-lg flex flex-col h-full">
              <div className="font-mono text-primary-500 text-sm mb-2">// VERIFIED</div>
              <h4 className="text-xl font-bold mb-2">CISSP</h4>
              <p className="text-gray-400 text-sm flex-grow">Certified Information Systems Security Professional</p>
              <div className="text-xs text-gray-500 mt-3">Achieved: 2022</div>
            </div>
            
            <div className="p-4 bg-dark-700 rounded-lg flex flex-col h-full">
              <div className="font-mono text-primary-500 text-sm mb-2">// ACHIEVEMENT</div>
              <h4 className="text-xl font-bold mb-2">HackerOne</h4>
              <p className="text-gray-400 text-sm flex-grow">Top 100 Security Researcher</p>
              <div className="text-xs text-gray-500 mt-3">2021 - Present</div>
            </div>
            
            <div className="p-4 bg-dark-700 rounded-lg flex flex-col h-full">
              <div className="font-mono text-primary-500 text-sm mb-2">// ACHIEVEMENT</div>
              <h4 className="text-xl font-bold mb-2">CTF Champion</h4>
              <p className="text-gray-400 text-sm flex-grow">Multiple first-place finishes in cybersecurity competitions</p>
              <div className="text-xs text-gray-500 mt-3">2019 - Present</div>
            </div>
            
            <div className="p-4 bg-dark-700 rounded-lg flex flex-col h-full">
              <div className="font-mono text-primary-500 text-sm mb-2">// VERIFIED</div>
              <h4 className="text-xl font-bold mb-2">AWS Security</h4>
              <p className="text-gray-400 text-sm flex-grow">AWS Certified Security - Specialty</p>
              <div className="text-xs text-gray-500 mt-3">Achieved: 2023</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;