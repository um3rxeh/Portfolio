import React, { useState } from 'react';
import { Project } from '../types';
import { Github, ExternalLink, ChevronRight, LockKeyhole, AlertTriangle, Server, Globe } from 'lucide-react';

const projectsData: Project[] = [
  {
    id: 1,
    title: 'VulnScanner',
    description: 'An advanced vulnerability scanner with custom exploit modules for web applications. Features dynamic testing and comprehensive reporting.',
    tags: ['Python', 'Web Security', 'OWASP', 'Automation'],
    imageUrl: 'https://images.pexels.com/photos/5473298/pexels-photo-5473298.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: '#',
    featured: true
  },
  {
    id: 2,
    title: 'NetGuardian',
    description: 'Network intrusion detection system with machine learning capabilities to identify anomalous behavior and potential breaches.',
    tags: ['Python', 'Machine Learning', 'Network Security', 'Real-time Analysis'],
    imageUrl: 'https://images.pexels.com/photos/4164762/pexels-photo-4164762.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: '#',
    featured: true
  },
  {
    id: 3,
    title: 'SecureAPI',
    description: 'A toolkit for testing and hardening RESTful APIs against common security vulnerabilities and implementation flaws.',
    tags: ['JavaScript', 'API Security', 'Penetration Testing'],
    imageUrl: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: '#',
    demoUrl: '#',
    featured: true
  },
  {
    id: 4,
    title: 'PhishDetector',
    description: 'Browser extension that uses AI to identify potential phishing sites and social engineering attempts in real-time.',
    tags: ['JavaScript', 'Machine Learning', 'Browser Extension'],
    imageUrl: 'https://images.pexels.com/photos/207580/pexels-photo-207580.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: '#',
    demoUrl: '#',
    featured: false
  },
  {
    id: 5,
    title: 'CryptoForensics',
    description: 'Digital forensics toolkit specialized in cryptocurrency transaction analysis and blockchain investigations.',
    tags: ['Python', 'Blockchain', 'Forensics', 'Cryptocurrency'],
    imageUrl: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: '#',
    featured: false
  },
  {
    id: 6,
    title: 'CloudGuard',
    description: 'Security auditing tool for cloud environments, focusing on misconfiguration detection and compliance verification.',
    tags: ['Go', 'Cloud Security', 'AWS', 'Azure', 'DevSecOps'],
    imageUrl: 'https://images.pexels.com/photos/2882566/pexels-photo-2882566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    githubUrl: '#',
    featured: false
  },
];

const Projects: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'featured'>('all');
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  
  const filteredProjects = filter === 'all' 
    ? projectsData 
    : projectsData.filter(project => project.featured);
    
  const getProjectIcon = (id: number) => {
    const icons = [<AlertTriangle size={20} />, <LockKeyhole size={20} />, <Globe size={20} />, <AlertTriangle size={20} />, <Server size={20} />, <Globe size={20} />];
    return icons[(id - 1) % icons.length];
  };

  return (
    <section id="projects" className="py-24 bg-dark-800">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-primary-500">&lt;</span> Projects <span className="text-primary-500">/&gt;</span>
          </h2>
          <div className="w-20 h-1 bg-primary-500 mx-auto mb-8"></div>
          <p className="text-gray-300 text-lg">
            A collection of security tools, research projects, and open-source contributions 
            that showcase my technical expertise and problem-solving approach.
          </p>
          
          <div className="flex justify-center mt-6 mb-12">
            <div className="bg-dark-700 rounded-full p-1 flex">
              <button
                className={`px-6 py-2 rounded-full transition-colors ${
                  filter === 'all' ? 'bg-primary-500 text-dark-900' : 'text-gray-300'
                }`}
                onClick={() => setFilter('all')}
              >
                All Projects
              </button>
              <button
                className={`px-6 py-2 rounded-full transition-colors ${
                  filter === 'featured' ? 'bg-primary-500 text-dark-900' : 'text-gray-300'
                }`}
                onClick={() => setFilter('featured')}
              >
                Featured
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map(project => (
            <div
              key={project.id}
              className="bg-dark-700 rounded-lg overflow-hidden border border-gray-700 hover:border-primary-500 transition-all group hover:shadow-[0_0_15px_rgba(0,255,140,0.1)]"
              onClick={() => setActiveProject(project)}
            >
              <div className="h-48 overflow-hidden relative">
                {project.imageUrl && (
                  <img 
                    src={project.imageUrl} 
                    alt={project.title} 
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900 to-transparent opacity-80"></div>
                {project.featured && (
                  <div className="absolute top-3 right-3 bg-primary-500 text-dark-900 text-xs font-bold px-2 py-1 rounded">
                    Featured
                  </div>
                )}
                <div className="absolute bottom-3 left-3 flex items-center text-sm font-mono">
                  <div className="w-8 h-8 bg-dark-800 rounded-full flex items-center justify-center mr-2 text-primary-500">
                    {getProjectIcon(project.id)}
                  </div>
                  <div className="text-white font-semibold">{project.title}</div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="mb-4">
                  <p className="text-gray-300 text-sm line-clamp-3">{project.description}</p>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, index) => (
                    <span 
                      key={index}
                      className="text-xs bg-dark-600 text-gray-300 px-2 py-1 rounded"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="flex items-center justify-between">
                  <button 
                    className="text-primary-500 flex items-center text-sm font-medium hover:underline"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveProject(project);
                    }}
                  >
                    View Details <ChevronRight size={16} className="ml-1" />
                  </button>
                  
                  <div className="flex space-x-2">
                    {project.githubUrl && (
                      <a 
                        href={project.githubUrl}
                        className="w-8 h-8 bg-dark-800 rounded-full flex items-center justify-center text-gray-400 hover:text-primary-500 transition-colors"
                        onClick={(e) => e.stopPropagation()}
                        aria-label="GitHub Repository"
                      >
                        <Github size={18} />
                      </a>
                    )}
                    {project.demoUrl && (
                      <a 
                        href={project.demoUrl}
                        className="w-8 h-8 bg-dark-800 rounded-full flex items-center justify-center text-gray-400 hover:text-primary-500 transition-colors"
                        onClick={(e) => e.stopPropagation()}
                        aria-label="Live Demo"
                      >
                        <ExternalLink size={18} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Project Details Modal */}
        {activeProject && (
          <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4">
            <div 
              className="bg-dark-800 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                className="absolute top-4 right-4 text-gray-400 hover:text-white bg-dark-700 rounded-full w-8 h-8 flex items-center justify-center z-10"
                onClick={() => setActiveProject(null)}
              >
                &times;
              </button>
              
              {activeProject.imageUrl && (
                <div className="h-64 md:h-80 overflow-hidden relative">
                  <img 
                    src={activeProject.imageUrl} 
                    alt={activeProject.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-900 to-transparent opacity-70"></div>
                </div>
              )}
              
              <div className="p-6 md:p-8">
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">{activeProject.title}</h3>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {activeProject.tags.map((tag, index) => (
                    <span 
                      key={index}
                      className="text-xs bg-dark-600 text-gray-300 px-2 py-1 rounded"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="prose prose-invert max-w-none mb-8">
                  <p className="text-gray-300 text-lg mb-4">{activeProject.description}</p>
                  <p className="text-gray-400">
                    This project demonstrates advanced techniques in cybersecurity research and tool development.
                    The implementation focuses on scalability, accuracy, and usability for security professionals.
                  </p>
                  
                  <h4 className="text-xl font-bold mt-6 mb-3">Key Features</h4>
                  <ul className="list-disc pl-5 text-gray-300 space-y-2">
                    <li>Advanced detection algorithms for zero-day vulnerabilities</li>
                    <li>Customizable scanning profiles for different security requirements</li>
                    <li>Comprehensive reporting with remediation recommendations</li>
                    <li>Integration capabilities with popular security platforms</li>
                    <li>Low false-positive rate compared to commercial solutions</li>
                  </ul>
                  
                  <h4 className="text-xl font-bold mt-6 mb-3">Technical Details</h4>
                  <p className="text-gray-400">
                    Built with security and performance in mind, this project utilizes modern development
                    practices and follows security-first design principles throughout its architecture.
                  </p>
                </div>
                
                <div className="flex flex-wrap gap-4">
                  {activeProject.githubUrl && (
                    <a 
                      href={activeProject.githubUrl}
                      className="px-6 py-3 bg-primary-500 text-dark-900 font-medium rounded-md hover:bg-primary-600 transition-colors flex items-center"
                    >
                      <Github size={20} className="mr-2" />
                      View Repository
                    </a>
                  )}
                  {activeProject.demoUrl && (
                    <a 
                      href={activeProject.demoUrl}
                      className="px-6 py-3 border border-primary-500 text-primary-500 font-medium rounded-md hover:bg-primary-900 transition-colors flex items-center"
                    >
                      <ExternalLink size={20} className="mr-2" />
                      Live Demo
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Projects;