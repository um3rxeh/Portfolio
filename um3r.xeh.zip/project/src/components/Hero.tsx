import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const [displayText, setDisplayText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const fullText = "Ethical Hacker | Cybersecurity Expert | Bug Hunter";
  const terminalRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (currentIndex < fullText.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + fullText[currentIndex]);
        setCurrentIndex(prevIndex => prevIndex + 1);
      }, 100);
      
      return () => clearTimeout(timeout);
    }
  }, [currentIndex]);
  
  useEffect(() => {
    const interval = setInterval(() => {
      if (terminalRef.current) {
        const commands = [
          'scanning vulnerabilities...',
          'bypassing firewall...',
          'accessing secure server...',
          'deploying exploit...',
          'analyzing network traffic...',
          'cracking encryption...',
          'injecting payload...',
        ];
        
        const randomCommand = commands[Math.floor(Math.random() * commands.length)];
        const newLine = document.createElement('div');
        newLine.classList.add('text-sm', 'text-gray-400', 'font-mono', 'mb-1');
        newLine.innerHTML = `<span class="text-primary-500">$</span> ${randomCommand}`;
        
        terminalRef.current.appendChild(newLine);
        
        // Keep only the last 5 lines
        while (terminalRef.current.childNodes.length > 5) {
          terminalRef.current.removeChild(terminalRef.current.firstChild as Node);
        }
        
        // Scroll to bottom
        terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
      }
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="home" className="min-h-screen bg-dark-900 flex flex-col justify-center relative pt-20">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
        <div className="w-full md:w-1/2 mb-12 md:mb-0">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="block mb-2">Hello, I'm</span>
            <span className="text-primary-500 font-mono">Um3r.xeh</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-6 font-mono">
            {displayText}
            <span className="inline-block animate-pulse">_</span>
          </p>
          <p className="text-gray-400 mb-8 max-w-lg">
            Transforming cyber vulnerabilities into opportunities for enhanced security. 
            With a focus on ethical hacking and penetration testing, I help organizations 
            strengthen their digital defenses.
          </p>
          <div className="flex flex-wrap gap-4">
            <a 
              href="#projects" 
              className="px-6 py-3 bg-primary-500 text-dark-900 font-medium rounded-md hover:bg-primary-600 transition-colors"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#projects')?.scrollIntoView({
                  behavior: 'smooth'
                });
              }}
            >
              View Projects
            </a>
            <a 
              href="#contact" 
              className="px-6 py-3 border border-primary-500 text-primary-500 font-medium rounded-md hover:bg-primary-900 transition-colors"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#contact')?.scrollIntoView({
                  behavior: 'smooth'
                });
              }}
            >
              Contact Me
            </a>
          </div>
        </div>
        <div className="w-full md:w-1/2 p-4">
          <div className="bg-dark-800 rounded-lg overflow-hidden border border-gray-700 shadow-xl">
            <div className="bg-dark-700 px-4 py-2 flex items-center">
              <div className="flex space-x-2 mr-4">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="font-mono text-sm text-gray-400">terminal@um3r.xeh: ~</div>
            </div>
            <div className="px-4 py-4 h-64 overflow-y-auto font-mono" ref={terminalRef}>
              <div className="text-sm text-gray-400 mb-1">
                <span className="text-primary-500">$</span> initializing secure connection...
              </div>
            </div>
          </div>
        </div>
      </div>
      <a 
        href="#about" 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gray-400 hover:text-primary-500 transition-colors animate-bounce"
        onClick={(e) => {
          e.preventDefault();
          document.querySelector('#about')?.scrollIntoView({
            behavior: 'smooth'
          });
        }}
      >
        <ChevronDown size={32} />
      </a>
    </section>
  );
};

export default Hero;