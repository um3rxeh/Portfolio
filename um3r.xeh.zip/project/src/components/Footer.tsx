import React from 'react';
import { Code, ArrowUp } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-dark-800 py-8 border-t border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between mb-8">
          <div className="flex items-center mb-6 md:mb-0">
            <Code size={28} className="text-primary-500 mr-2" />
            <span className="text-xl font-bold text-white font-mono">Um3r.xeh</span>
          </div>
          
          <div className="flex space-x-8">
            <a href="#home" className="text-gray-400 hover:text-primary-500 transition-colors">Home</a>
            <a href="#about" className="text-gray-400 hover:text-primary-500 transition-colors">About</a>
            <a href="#skills" className="text-gray-400 hover:text-primary-500 transition-colors">Skills</a>
            <a href="#projects" className="text-gray-400 hover:text-primary-500 transition-colors">Projects</a>
            <a href="#contact" className="text-gray-400 hover:text-primary-500 transition-colors">Contact</a>
          </div>
          
          <button 
            onClick={scrollToTop}
            className="w-10 h-10 bg-dark-700 rounded-full flex items-center justify-center text-gray-400 hover:text-primary-500 hover:border-primary-500 border border-gray-700 transition-all mt-6 md:mt-0"
            aria-label="Scroll to top"
          >
            <ArrowUp size={18} />
          </button>
        </div>
        
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between text-gray-500 text-sm">
          <div className="mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Um3r.xeh. All rights reserved.
          </div>
          
          <div className="text-center md:text-right">
            <div className="font-mono">
              <span className="text-primary-500">$</span> echo "Security is a journey, not a destination"
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;