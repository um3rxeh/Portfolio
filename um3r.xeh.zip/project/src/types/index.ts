export interface Skill {
  name: string;
  level: number;
  category: 'offensive' | 'defensive' | 'development' | 'infrastructure';
  icon?: string;
}

export interface Project {
  id: number;
  title: string;
  description: string;
  tags: string[];
  imageUrl?: string;
  demoUrl?: string;
  githubUrl?: string;
  featured: boolean;
}

export interface NavItem {
  name: string;
  href: string;
}