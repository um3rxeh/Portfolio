/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          500: '#00FF8C',
          600: '#00CC70',
          900: 'rgba(0, 255, 140, 0.15)',
        },
        secondary: {
          500: '#0070FF',
          600: '#0060D6',
        },
        dark: {
          900: '#050505',
          800: '#0F0F0F',
          700: '#1E1E1E',
          600: '#292929',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
        mono: ['JetBrains Mono', 'ui-monospace', 'Consolas'],
      },
      animation: {
        'pulse': 'pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce': 'bounce 1.5s infinite',
        'glitch': 'glitch 1s infinite',
      },
      keyframes: {
        pulse: {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0 },
        },
      },
    },
  },
  plugins: [],
};